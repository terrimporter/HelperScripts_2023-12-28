cd /home/terri/ncbi-blast-2.4.0+/db/
sudo update_blastdb --passive --decompress nt
sudo chown root *
sudo chgrp root *
sudo chmod 755 *
